import React, { Component } from 'react';
import { connect } from 'react-redux';  // to connect the component as part of mapStateToProps
import { withRouter } from 'react-router-dom'; //will pass updated props to the wrapped component
import PropTypes from 'prop-types';
import BarChart from 'react-bar-chart';

const margin = {top: 0, right: 0, bottom: 0, left: 40};

class StationStatusBar extends Component {

	constructor(props) {
		super(props);
		this.state = { 
			colors: ['#2D5FD9', '#FFFFFF']
		};
	}
	
  render() {
  
	let activePerc = 80;	
	let inactivePerc =this.props.inactivePerc ;
	
	let maxBarHeight = this.props.maxBarHeight;
	let marginTop = (60 - activePerc) + 'px';
	//let lineMarginBotm = (35 + (Integer.parseInt(maxBarHeight)) - 95) + 'px';
	
	console.log("---------ACtive Perc");
	console.log(activePerc);
	
	console.log("---------InACtive Perc");
	console.log(inactivePerc);
	console.log(marginTop);
	console.log("lineMarginBotm");
	//console.log(lineMarginBotm);
	
	let data1 = [
	  {value: activePerc} 
	];
	
	let data2 = [
	  {value: inactivePerc} 
	];

	let activeWidth = 100;
	let inActiveWidth = 30;
	
	let scale = value => { 
		// some color selection
		return '#2D5FD9';
	};
	
	
	
    return (
        <div className="mainCustomBar">
			              
				<div className="leftBar" style={{ marginTop: marginTop }} >
					<BarChart 
						//ylabel='Quantity'
						width={10}
						height={activePerc}
						data={data1}						
					/>
				</div>
				<div className="customLine" >&nbsp;</div>
				<div className="rightBar" >
					<BarChart 
					  //ylabel='Quantity'
					  width={10}
					  height={inactivePerc}
					  data={data2}
					/>
				</div>
        </div>
    );
  }
}

export default StationStatusBar;
