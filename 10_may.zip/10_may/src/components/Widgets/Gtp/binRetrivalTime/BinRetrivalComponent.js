//Top Authors widget

import React, { Component } from 'react'
import {Button, ButtonGroup, Carousel} from 'react-bootstrap'

import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';

// intl messages
import IntlMessages from 'Util/IntlMessages';

import Spline from './Spline';

const bins = [
	   {
	      id: 1,
	      name: "Overall"
	   },
	   {
		      id: 2,
		      name: "Picking"
	   },
	   {
	      id: 3,
	      name: "Consolidation"
	   },
	   {
	      id: 4,
	      name: "Decanting"
	   },
	   {
	      id: 5,
	      name: "Cycle Count"
	   }
	]

export default class BinRetrivalComponent extends Component {
	state = {
        activeIndex: 0
    }

    handleTabChange(value) {
        this.setState({ activeIndex: value });
    }
   render() {
	   
	   let opt = {
				data: [[0, 0,  0, 0, 0, 0,0, 25, 30, 25, 0, 0 ]],
				colors: ['#7B43A1'],// Line Color
				axis: [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65],
				targetvalue:6,
				currentposition:8
			
		}
	  const { activeIndex } = this.state;
      const settings = {
			   interval: null,
			   indicators: false,
			   //nextIcon: <span aria-hidden='true' className='icon-arrow-left' />,
			   //prevIcon: <span aria-hidden='true' className='carousel-control-next-icon' />
	   };
      //console.log(asd)
      return (
    		  
    		  <div>
    		  		<div>
						{/*<div className={"float-right"} style={{width:"40%"}}>
							<Tabs
								value={activeIndex}
								onChange={(e, value) => this.handleTabChange(value)}
								textColor="inherit"
								color="#333333"
								indicatorColor="primary"
							>
								<Tab label={<IntlMessages id={'GTP.binRetrival.Day'} />}/>
								<Tab label={<IntlMessages id={'GTP.binRetrival.Week'} />}/>
							</Tabs>
						</div>*/}
					  	<ButtonGroup className="btn-group dayweek float-right">
							<Button style={{zIndex: "0"}} key={1} className="active btn-primry" variant="light"><IntlMessages id={'GTP.binRetrival.Day'} /></Button>
							<Button style={{zIndex: "0"}} key={2} className="btn-primry" variant="light"><IntlMessages id={'GTP.binRetrival.Week'} /></Button>
						</ButtonGroup>
						<h4 className="title float-left"><IntlMessages id={'GTP.binRetrival.title'} /></h4>
					</div>
					<div className="clearfix" ></div>
					<div className="author-detail-wrap d-flex justify-content-between flex-column">
						<Carousel {...settings}>
							{bins && bins.map((bin, key) => (
								<Carousel.Item key={bin.id}>
									<div className="author-avatar overlay-wrap mb-5">
									<div className="avatar-img text-center">
										<h5 className="binTitle"><IntlMessages id={`GTP.binRetrival.${bin.name}`} /></h5>
									</div>
									<div className="authors-info text-center">
											<Spline opt={opt} />
									</div>	
									</div>
								</Carousel.Item>
							))}
						</Carousel> 
					</div>
    		  </div>
      )
   }
}
