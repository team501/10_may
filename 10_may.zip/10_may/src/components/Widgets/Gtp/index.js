import React, { Component } from 'react';

// intl messages
import IntlMessages from 'Util/IntlMessages';
import NumberClass from 'Util/NumberClass';
import {graphQlURLPrd} from 'GraphQlUrl/Config';

//json
import json from 'JsnCnfg/WrkMntrng/GTPDshbrd/ovrlWrkMntr.json';
//rct collapsible card
import RctCollapsibleCard from 'Components/RctCollapsibleCard/RctCollapsibleCard';

// Import custom examples
import SegmentedArcProgressbar from './arc/SegmentedArcProgressbar';
import StationStatusBar from './BarChart';

class OverallWorkMonitor extends Component {
	constructor(props) {
		super(props);
		this.startTime = 201903181431;//dateFormat(new Date(), "yyyymmddHHMM");
		this.goalVal = this.props.goal;
		this.state = {
				productivityPercentage: 0,
				stationStatusTotal: 0,
				stationStatusActive: 0,
				stationStatusInactive: 0,
				binStatusProcessed:0,
				binStatusLastHour: 0
		}
	}

	/*calling rest for the first time after mount
	 *it will call render twice but update only once
	 *Used to remove unsafe life cycle methods.*/
	componentDidMount() {
		this.getProductivity();
		this.getActiveStationStatus();
		this.getInactiveStationStatus();
		this.getTotalStationStatus();
		this.getBinsProcessed();
		this.getBinsProcessedLastHour();
	}

	//Comparing props and triggering refresh 
	componentDidUpdate(prevProps) {
		// Typical usage (don't forget to compare props):
		if (this.props.currentTime !== prevProps.currentTime) {
			this.startTime = 201903181431;//dateFormat(new Date(), "yyyymmddHHMM");
			this.getProductivity();
			this.getActiveStationStatus();
			this.getInactiveStationStatus();
			this.getTotalStationStatus();
			this.getBinsProcessed();
			this.getBinsProcessedLastHour();
		}
	}
	
	getProductivity() {
		let startTime = this.startTime;
		let goalVal = this.goalVal;
		
		
		/*Productivity*/
		let query = 'query GetProductivity($startTime: Long!, $goalVal: Int) {getProductivity( startTime: $startTime, xMins: 60, zoneId: "", function: "", goal: $goalVal )}';
		fetch(graphQlURLPrd, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json'},
											   body: JSON.stringify({ query, variables: { startTime, goalVal } })
		}).then(r => r.json())
		.then(data => { 
						this.setState(
							{ 
								productivityPercentage: data.data.getProductivity,
								isLoading:false
							}
						); 
		})
		.catch((error) => {
			console.log(error);
			this.setState({ productivityPercentage: 0,
						    isLoading:false
						  }); 
		});
	}
	
	getActiveStationStatus() {
		let startTime = this.startTime;
		
		/*Active Stations*/
		let query = 'query GetNumberOfActiveGTPStations($startTime: Long!) {getNumberOfActiveGTPStations( startTime: $startTime, zoneId: "", function: "")}';
		fetch(graphQlURLPrd, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json'},
											   body: JSON.stringify({ query, variables: { startTime} })
		}).then(r => r.json())
		.then(data => { 
						this.setState(
							{ 
								stationStatusActive: data.data.getNumberOfActiveGTPStations,
								isLoading:false
							}
						); 
		})
		.catch((error) => {
			console.log(error);
			this.setState({ stationStatusActive: 0,
						    isLoading:false
						  }); 
		});
	}
	
	getInactiveStationStatus() {
		let startTime = this.startTime;
		
		/*Inactive Stations*/
		let query = 'query GetNumberOfInactiveGTPStations($startTime: Long!) {getNumberOfInactiveGTPStations( startTime: $startTime, zoneId: "", function: "")}';
		fetch(graphQlURLPrd, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json'},
											   body: JSON.stringify({ query, variables: { startTime} })
		}).then(r => r.json())
		.then(data => {
						this.setState(
							{ 
								stationStatusInactive: data.data.getNumberOfInactiveGTPStations,
								isLoading:false
							}
						); 
		})
		.catch((error) => {
			console.log(error);
			this.setState({ stationStatusInactive: 0,
						    isLoading:false
						  }); 
		});
	}
	
	getTotalStationStatus() {
		let startTime = this.startTime;
		
		/*All Stations*/
		let query = 'query GetTotalGTPStations($startTime: Long!) { getTotalGTPStations( startTime: $startTime, zoneId: "", function: "")}';
		fetch(graphQlURLPrd, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json'},
											   body: JSON.stringify({ query, variables: { startTime} })
		}).then(r => r.json())
		.then(data => { 
						this.setState(
							{ 
								stationStatusTotal: data.data.getTotalGTPStations,
								isLoading:false
							}
						); 
		})
		.catch((error) => {
			console.log(error);
			this.setState({ stationStatusTotal: 0,
						    isLoading:false
						  }); 
		});
	}
	
	getBinsProcessed() {
		let startTime = this.startTime;
		
		/*All Stations*/
		let query = 'query getNumberOfBinsProcessed($startTime: Long!) { getNumberOfBinsProcessed( startTime: $startTime, zoneId: "", function: "")}';
		fetch(graphQlURLPrd, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json'},
											   body: JSON.stringify({ query, variables: { startTime} })
		}).then(r => r.json())
		.then(data => { 
						this.setState(
							{ 
								binStatusProcessed: data.data.getNumberOfBinsProcessed,
								isLoading:false
							}
						); 
		})
		.catch((error) => {
			console.log(error);
			this.setState({ binStatusProcessed: 0,
						    isLoading:false
						  }); 
		});
	}
	
	getBinsProcessedLastHour() {
		let startTime = this.startTime;
		
		/*All Stations*/
		let query = 'query getNumberOfBinsProcessed($startTime: Long!) { getNumberOfBinsProcessed( startTime: $startTime, zoneId: "", xMins: 60, function: "")}';
		fetch(graphQlURLPrd, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json'},
											   body: JSON.stringify({ query, variables: { startTime} })
		}).then(r => r.json())
		.then(data => { 
						this.setState(
							{ 
								binStatusLastHour: data.data.getNumberOfBinsProcessed,
								isLoading:false
							}
						); 
		})
		.catch((error) => {
			console.log(error);
			this.setState({ binStatusLastHour: 0,
						    isLoading:false
						  }); 
		});
	}
	render(){
	const percentage = this.state.productivityPercentage;
	
	{/* Calculation For Station Status */}
	
	let total = this.state.stationStatusTotal;
	let active = this.state.stationStatusActive;
	let inActive = this.state.stationStatusInactive;
	let maxBarHeight = 95;
	let maxBarHeightWitPx = maxBarHeight+ 'px';

	let activePerc = ( active / total )* maxBarHeight; 
	let inactivePerc = ( inActive/ total )* maxBarHeight;
	
	console.log("========= inside GTP index - Station Status =========");
	console.log("maxBarHeightWitPx ");
	console.log(maxBarHeightWitPx);
	
	console.log("ACtive Perc");
	console.log(activePerc);
	
	console.log("InACtive Perc");
	console.log(inactivePerc);
		
	{/*................................*/}
	
      return(
	  <RctCollapsibleCard	colClasses="col-sm-12 col-md-12 col-lg-12 w-xs-full ovlWrkCard"> 
        <div className="app-horizontal collapsed-sidebar">
        <div className="app-container">
            <div className="rct-page-wrapper">
                <div className="rct-app-content">
                    <div className="app-header">
                      <div className="overall-work-monitor">
                       <div className="title"><IntlMessages id="GTP.overallWork" /></div>
											 	<div className="col-sm-4 col-md-4 col-lg-4 col-xl-4 text-center leftAlign nopadding">
													<div className="subtitle"><b><IntlMessages id="GTP.overallWork.Productivity" /></b></div>
														<div className="overAllG">
															<div 
																className="ArcGauge" 
																style={{ 
																	width: `${json.container.leftSegment.components[0].options.width}px`, 
																	height: `${json.container.leftSegment.components[0].options.width}px`
																}}
															>
																<SegmentedArcProgressbar 
																	percentage={percentage}  
																	segments={json.container.leftSegment.components[0].options.segments} 
																	textColor={json.container.leftSegment.components[0].options.textColor}
																	segmentColors={json.container.leftSegment.components[0].options.segmentColors}
																	segmentPercentage={json.container.leftSegment.components[0].options.segmentPercentage}
																	barWidth={json.container.leftSegment.components[0].options.barWidth}
																/>
															</div>
														</div>
														<div className="titleBar"><IntlMessages id="GTP.overallWork.TotalAverage" /></div>
														<div className="station-status-activetext"><i>(<IntlMessages id="GTP.overallWork.LastHour" />)</i></div>
												</div>
												<div className="col-sm-4 col-md-4 col-lg-4 col-xl-4 text-center leftAlign nopadding">
												<div className="subtitle"><b><IntlMessages id="GTP.overallWork.StationStatus" /></b></div>
													<div>
														<div className="station-status-textblack marginBotTot"><NumberClass  number={this.state.stationStatusTotal} /></div> 
														<div className="station-status-activetext margin24"><IntlMessages id="GTP.overallWork.Total" /></div>
													</div>
											<div className="customBarWitLbl" >
											 	<div className="activeStnSts">
														<div className="station-status-textblack marginBotActive"><NumberClass  number={this.state.stationStatusActive} /></div> 
														<div className="station-status-activetext"><IntlMessages id="GTP.overallWork.Active" /></div>
													</div>
												
												{/* For Station Status Bar Chart */}
												<div className="customBarStnSts" style= {{ height: maxBarHeight }}>
													<StationStatusBar  activePerc={activePerc} inactivePerc={inactivePerc} /> 
												</div>
												<div className="inactiveStnSts" >
														<div className="station-status-textblack marginBotActive"><NumberClass  number={this.state.stationStatusInactive} /></div>
														<div className="station-status-activetext"><IntlMessages id="GTP.overallWork.Inactive" /></div>
													</div> 
											</div>
												</div>
												<div className="col-sm-4 col-md-4 col-lg-4 col-xl-4 text-center leftAlign nopadding">
												<div className="subtitle"><b><IntlMessages id="GTP.overallWork.BinStatus" /></b></div>
												<div>
														<div className="station-status-textblack marginBotTot"><NumberClass  number={this.state.binStatusProcessed} /></div> 
														<div className="station-status-activetext margin24"><IntlMessages id="GTP.overallWork.Processed" /></div>
													</div>
												<div>
														<div className="station-status-textblack marginBotTot"><NumberClass  number={this.state.binStatusLastHour} /></div> 
														<div className="station-status-labeltext"><IntlMessages id="GTP.overallWork.ProcessRate" /></div>
														<div className="station-status-activetext"><i>(<IntlMessages id="GTP.overallWork.LastHour" />)</i></div>
														
													</div>
												</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
               </RctCollapsibleCard>       
      );
    }
  }
export default OverallWorkMonitor;
